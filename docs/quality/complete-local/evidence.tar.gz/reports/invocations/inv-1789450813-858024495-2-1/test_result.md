=== Verification report ===
Timestamp: 2026-09-15T05:41:11.518240699+00:00
Profile: ci
Components: backend,frontend

- PASS: secret scan (999 ms)
- PASS: architecture audit (20 ms) - 0 violation(s), 0 blocker(s), 0 error(s), 0 warning(s)
- PASS: backend format (85 ms)
- PASS: backend Clippy (33116 ms)
- PASS: backend compile (575 ms)
- PASS: backend tests (1537 ms) - 5 result(s)
- PASS: frontend lint (4339 ms)
- PASS: frontend tests (6424 ms) - 6 result(s)
- PASS: frontend production build (6750 ms)
Quality profile "ci": pass (complete); full quality: pass

TEST_SUMMARY: PASS
